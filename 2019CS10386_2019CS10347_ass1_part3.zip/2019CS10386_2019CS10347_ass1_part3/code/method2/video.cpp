#include <iostream>
#include <opencv2/opencv.hpp>
#include "modifierFunctions.hpp"
#include "bgEditor.hpp"
#include <sstream>
#include <fstream>
#include <opencv2/imgcodecs.hpp>
#include <opencv2/imgproc.hpp>
#include <opencv2/videoio.hpp>
#include <opencv2/highgui.hpp>
#include <opencv2/video.hpp>
#include <chrono>

using namespace cv;
using namespace std;
using namespace std::chrono;

int main(int argc, char* argv[])
{
    //To check if input is null
    if(argv[1]==NULL){
        std::cout << "Video input not given ,check readme file for help" << std::endl;
        return 1;
    }
    //To check if the video input file does not exist
    ifstream ifile;
    ifile.open(argv[1]);
    if(!ifile) {
        cout<<"Video file doesn't exist in current directory"<<"\n";
        return 0;  
    }
    //opening the video file
    string instream = argv[1];
    VideoCapture capture( samples::findFile( instream ) );
    if (!capture.isOpened()){
        cerr << "Unable to open: " << instream << endl;
        return 0;
    }
    cv::Mat frame;
    cv::Mat empty = cv::imread("cropped_road.png",cv::IMREAD_GRAYSCALE); //empty frame for queue density evaluation
    cv::Mat previous = empty; //This matrix will store the value of the previous frame
 
    //points specify the region which is angle corrected and cropped
    std::vector<cv::Point2f> points;
    points.push_back(Point2f(977,212));
    points.push_back(Point2f(311,1059));
    points.push_back(Point2f(1530,1058));
    points.push_back(Point2f(1264,210));
    cout<<"frame_number"<<" "<<"queue density"<<" "<<"dynamic density"<<"\n";

    //fstream used to append the output densities in the "out.txt" file
    fstream file,file2;
    file.open("raw_out1.txt",ios::out | ios::in);
    file2.open("raw_out3.txt",ios::out | ios::in);
    int frame_number=0; //keeps count of the frame
    double error=0,error1=0,error2=0,error3=0,error4=0,error5=0,error6=0;
    //auto start = high_resolution_clock::now();
    while (true) {  //loop for traversing through all the frames of the video file
        capture >> frame;
        cv:: Mat grayscale;
        if (frame.empty())
            break;
        //size of frame discribed by rectangle
        rectangle(frame, cv::Point(10, 2), cv::Point(100,20),
                  cv::Scalar(255,255,255), -1);
        //To change color to grayscale
        cvtColor(frame, grayscale, COLOR_RGB2GRAY);
        //for frame number of the playing video
        stringstream ss;
        ss << capture.get(CAP_PROP_POS_FRAMES);
        string frameNumberString = ss.str();
        putText(frame, frameNumberString.c_str(), cv::Point(15, 15),
                FONT_HERSHEY_SIMPLEX, 0.5 , cv::Scalar(0,0,0));
        //angle corrected and cropped image produced using functions defined in the previous assignment
        cv::Mat angleCorrectedImage = changePerspective(grayscale, points);
        cv::Mat croppedImage = cropImage(angleCorrectedImage);
        Mat frame1,frame2,frame3,frame4,frame5,frame6,frame7,frame8,frame9,frame10,frame11,frame12,frame13,frame14,frame15,frame16,frame17,frame18;
        resize(croppedImage,frame1,Size(100,100));
        resize(empty,frame2,Size(100,100));
        resize(previous,frame3,Size(100,100));

        resize(croppedImage,frame4,Size(33,78));
        resize(empty,frame5,Size(33,78));
        resize(previous,frame14,Size(33,78));

        resize(croppedImage,frame6,Size(164,389));
        resize(empty,frame7,Size(164,389));
        resize(previous,frame15,Size(164,389));

        resize(croppedImage,frame8,Size(246,583.5));
        resize(empty,frame9,Size(246,583.5));
        resize(previous,frame16,Size(246,583.5));

        resize(croppedImage,frame10,Size(82,194.5));
        resize(empty,frame11,Size(82,194.5));
        resize(previous,frame17,Size(82,194.5));

        resize(croppedImage,frame12,Size(656,1556));
        resize(empty,frame13,Size(656,1556));
        resize(previous,frame18,Size(656,1556));

        double xyby10 = getQueue(frame4,frame5);
        double xy100 = getQueue(frame1,frame2);
        double xydiv4 = getQueue(frame10,frame11);
        double xydiv2 = getQueue(frame6,frame7);
        double xy3div4 = getQueue(frame8,frame9);
        double queue = getQueue(croppedImage,empty);
        double xymul2 = getQueue(frame12,frame13);
        //double xyby10 = getDynamic(frame4,frame14,frame5);
        //double xy100 = getDynamic(frame1,frame3,frame2);
        //double xydiv4 = getDynamic(frame10,frame17,frame11);
        //double xydiv2 = getDynamic(frame6,frame15,frame7);
        //double xy3div4 = getDynamic(frame8,frame16,frame9);
        //double queue = getQueue(croppedImage,empty); //stores the queue density*/
        //double dynamic = getDynamic(croppedImage,previous,empty); //stores the dynamic density
        //double xymul2 = getDynamic(frame12,frame18,frame13);
        /*error1+= abs(xy100-dynamic);
        error2+=abs(xyby10-dynamic);
        error3+=abs(xydiv2-dynamic);
        error4+=abs(xy3div4-dynamic);
        error5+=abs(xydiv4-dynamic);
        error6+=abs(xymul2-dynamic);*/
        error1+= abs(xy100-queue);
        error2+=abs(xyby10-queue);
        error3+=abs(xydiv2-queue);
        error4+=abs(xy3div4-queue);
        error5+=abs(xydiv4-queue);
        error6+=abs(xymul2-queue);
        //cout<<croppedImage.cols<<" "<<croppedImage.rows<<"\n";
        cout<<frame_number<<" "<<queue<<" "<<" "<<xy100<<" "<<xyby10<<" "<<xydiv2<<" "<<xy3div4<<" "<<xydiv4<<" "<<xymul2<<"\n"; //return the values in console
        file<<frame_number<<" "<<queue<<" "<<" "<<xy100<<" "<<xyby10<<" "<<xydiv2<<" "<<xy3div4<<" "<<xydiv4<<" "<<xymul2<<"\n"; //return the values in the "out.txt"
        previous = croppedImage; //so that previous points to the previous frame 
        //imshow("Density", croppedImage); //video displayed
        frame_number++;
        //Press any key to exit the program
        int keyboard = waitKey(30); 
        if (keyboard >= 65 && keyboard <= 122 || keyboard == 27)
            break;
    }
    //auto stop = high_resolution_clock::now();
    //auto duration = duration_cast<seconds>(stop - start);
    //cout << "Time taken by function: "<< duration.count() << " seconds" << endl;
    cout<<error2/frame_number<<" "<<error1/frame_number<<" "<<error5/frame_number<<" "<<error3/frame_number<<" "<<error4/frame_number<<" "<<error/frame_number<<" "<<error6/frame_number<<" "<<"\n";
    file2<<error2/frame_number<<" "<<error1/frame_number<<" "<<error5/frame_number<<" "<<error3/frame_number<<" "<<error4/frame_number<<" "<<error/frame_number<<" "<<error6/frame_number<<" "<<"\n";
    file.close();
    file2.close();
    return 0;
}
