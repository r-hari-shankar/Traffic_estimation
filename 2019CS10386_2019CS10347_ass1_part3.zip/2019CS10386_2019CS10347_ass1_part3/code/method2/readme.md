# Method 2 code

## How to execute the program
Follow these simple steps to execute the program
1) In terminal write cd "path of the program folder" to change to the folder containing the program files.
2) Make sure the benchmark video files whose Analysis to be done is in the directory.
3) <i> Type "make" in the terminal without quotes.
4) Type "./traffic_density.out <video_name.extension>" <br>
    <t> eg) ./traffic_density.out trafficvideo.mp4 <br>
    <t> Note: if improper or no input is provided, an error will be shown.</i>
5) Please note that to get the values of the runtime the comments in line 56,133-135 need to be uncommented and comments to be added to the part of code not to be used during that process in the video.cpp file. 
6) Press any key to exit the program . The density values are stored in the filename you write in line 53 of video.cpp for future references.
8) Type "make clean" in the terminal to clear all the object files. 

