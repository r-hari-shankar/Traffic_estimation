# Method 4 code

## How to execute the program
Follow these simple steps to execute the program
1) In terminal write cd "path of the program folder" to change to the folder containing the program files.
2) Make sure the benchmark video files whose Analysis to be done is in the directory.
3) <i> Type "make" in the terminal without quotes.
4) Type "./traffic_density.out <video_name.extension>" <br>
    <t> eg) ./traffic_density.out trafficvideo.mp4 <br>
    <t> Note: if improper or no input is provided, an error will be shown.</i>
5) The implementation in this code is for 8 thread implementation for lower no. of thread some lines of code need to be commented in file video.cpp. 
6) Press any key to exit the program . The density values are stored in the filename you write in line 75 of video.cpp for future references.
8) Type "make clean" in the terminal to clear all the object files. 


