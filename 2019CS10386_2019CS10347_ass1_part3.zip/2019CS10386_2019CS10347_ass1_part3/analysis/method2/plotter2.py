import matplotlib.pyplot as plt
import itertools

#fig.suptitle("Graph for method 2")
file = open("raw_out2.txt", "r")
xvalues = []
baseline = []
xy100 = [] 
xyby10 = []
xydiv2 = []
xy3div4 = []
xydiv4 = []
xymul2 = []
i=0
for line in file:
    a = line.split()
    xvalues.append(int(a[0]))
    baseline.append(float(a[1]))
    xy100.append(float(a[2]))
    xyby10.append(float(a[3]))
    xydiv2.append(float(a[4]))
    xy3div4.append(float(a[5]))
    xydiv4.append(float(a[6]))
    xymul2.append(float(a[7]))

file.close()

plt.plot(xvalues, baseline, label = "baseline 328*778")
plt.plot(xvalues, xy100, label = "100*100")
plt.plot(xvalues, xyby10, label = "33*78")
plt.plot(xvalues, xydiv2, label = "164*389")
plt.plot(xvalues, xy3div4, label = "246*583.5")
plt.plot(xvalues, xydiv4, label = "82*194.5")
plt.plot(xvalues, xymul2, label = "656*1556")


plt.xlabel("Frame number")
plt.ylabel("Densities")
plt.legend()
plt.savefig("dynamicdensity.png")
plt.show()