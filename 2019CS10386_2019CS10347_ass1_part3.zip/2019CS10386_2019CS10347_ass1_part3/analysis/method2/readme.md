#Method 2 analysis

## Output files
1) raw_out1.txt , raw_out2.txt are output files containing values of queue and dynamic density respectively for various parameters. The different columns correspond to frame number ,328*778 ,100*100 ,33*78 ,164*389,246*583.5,82*194.5 respectively.
2)raw_out3.txt,raw_out4.txt are output files containing values of utility ,runtime for different parameter for queue and dynamic density respectively.

## Plotter programs
The plotter.py is used for plotting the various graphs of raw_out3.txt (the comments in program are used for plotting different graphs)
The plotter1.py is used for plotting the various graphs of raw_out4.txt (the comments in program are used for plotting different graphs)
The plotter2.py is used for plotting the various graphs of raw_out1.txt and raw_out2.txt (the comments in program are used for plotting different graphs)

## Graphs
All the graphs compiled from this method are enclosed in this folder.

