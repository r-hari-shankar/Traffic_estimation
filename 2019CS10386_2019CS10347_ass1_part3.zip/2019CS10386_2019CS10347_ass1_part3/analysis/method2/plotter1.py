import matplotlib.pyplot as plt
import itertools

#fig.suptitle("Graph for method 2")
file = open("raw_out4.txt", "r")
param = []
utility = [] 
runtime = []
i=0
for line in file:
    a = line.split()
    utility.append(float(a[0]))
    runtime.append(int(a[1]))
    param.append(a[2])

file.close()
#plt.plot(runtime, utility, label = "Utility Runtime graph")
#plt.plot(param, utility, label = "Utility-Parameter graph")
plt.plot(param, runtime, label = "Runtime-Parameter graph")
plt.xlabel("Parameter")
plt.ylabel("Runtime")
plt.legend()
plt.savefig("RPdynamic1.png")
plt.show()
