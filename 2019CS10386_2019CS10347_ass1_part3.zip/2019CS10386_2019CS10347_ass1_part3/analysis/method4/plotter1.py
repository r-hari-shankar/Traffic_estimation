import matplotlib.pyplot as plt


file = open("core_runtime.txt", "r")
xvalues = []
y1values = [] 
y2values = []

for line in file:
    a = line.split()
    xvalues.append(int(a[0]))
    y1values.append(int(a[1]))
    y2values.append(float(a[2]))

plt.plot(xvalues, y2values, label = "error vs thread")
#plt.plot(xvalues, y1values, label = "threads vs runtime")
plt.xlabel("Number of threads")
plt.ylabel("utility(error)")
plt.legend()
plt.savefig("threadvserror.png")
plt.show()
