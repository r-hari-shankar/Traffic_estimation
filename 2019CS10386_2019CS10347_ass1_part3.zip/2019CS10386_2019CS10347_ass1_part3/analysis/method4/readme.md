#Method 4 analysis

## Output files
1) The output files core1.txt - core8.txt contains the frame number and queue density values by using the number of threads as given in the filename.
2) core_runtime.txt contains number of threads,runtime ,total error compared to baseline 

## Plotter programs
The plotter.py is used for plotting the graph comparing the queue density for different number of threads.
The plotter1.py is used for plotting the thread vs utility and thread vs runtime (the comments in program are used for plotting different graphs)

## Graphs
All the graphs compiled from this method are enclosed in this folder.

