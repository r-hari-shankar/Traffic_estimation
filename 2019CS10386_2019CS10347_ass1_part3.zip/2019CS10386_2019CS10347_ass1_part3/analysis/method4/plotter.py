import matplotlib.pyplot as plt

file1 = open("core1.txt", "r")
file2 = open("core2.txt", "r")
file3 = open("core3.txt", "r")
file4 = open("core4.txt", "r")
file5 = open("core5.txt", "r")
file6 = open("core6.txt", "r")
file7 = open("core7.txt", "r")
file8 = open("core8.txt", "r")
x1values = []
y1values = [] 
x2values = []
y2values = [] 
x3values = []
y3values = [] 
x4values = []
y4values = [] 
x5values = []
y5values = [] 
x6values = []
y6values = [] 
x7values = []
y7values = [] 
x8values = []
y8values = [] 
error1=0
error2=0
error3=0
error4=0
error5=0
error6=0
error7=0
error8=0

for line in file1:
    a = line.split()
    x1values.append(int(a[0]))
    y1values.append(float(a[1]))
    #print(int(a[0]))
    #y2values.append(a[2])
for line in file2:
    a = line.split()
    x2values.append(int(a[0]))
    y2values.append(float(a[1]))
    k=y1values[int(a[0])];
    error2+= abs(float(a[1])-k)

for line in file3:
    a = line.split()
    x3values.append(int(a[0]))
    y3values.append(float(a[1]))
    k=y1values[int(a[0])];
    error3+= abs(float(a[1])-k)

for line in file4:
    a = line.split()
    x4values.append(int(a[0]))
    y4values.append(float(a[1]))
    k=y1values[int(a[0])];
    error4+= abs(float(a[1])-k)

for line in file5:
    a = line.split()
    x5values.append(int(a[0]))
    y5values.append(float(a[1]))
    k=y1values[int(a[0])];
    error5+= abs(float(a[1])-k)

for line in file6:
    a = line.split()
    x6values.append(int(a[0]))
    y6values.append(float(a[1]))
    k=y1values[int(a[0])];
    error6+= abs(float(a[1])-k)

for line in file7:
    a = line.split()
    x7values.append(int(a[0]))
    y7values.append(float(a[1]))
    k=y1values[int(a[0])];
    error7+= abs(float(a[1])-k)

for line in file8:
    a = line.split()
    x8values.append(int(a[0]))
    y8values.append(float(a[1]))
    k=y1values[int(a[0])];
    error8+= abs(float(a[1])-k)
print(error1)
print(error2)
print(error3)
print(error4)
print(error5)
print(error6)
print(error7)
print(error8)
plt.plot(x1values, y1values, label = "#thread = 1")
plt.plot(x2values, y2values, label = "#thread = 2")
plt.plot(x3values, y3values, label = "#thread = 3")
plt.plot(x4values, y4values, label = "#thread = 4")
plt.plot(x5values, y5values, label = "#thread = 5")
plt.plot(x6values, y6values, label = "#thread = 6")
plt.plot(x7values, y7values, label = "#thread = 7")
plt.plot(x8values, y8values, label = "#thread = 8")

plt.xlabel("frame number")
plt.ylabel("queue densities")
plt.legend(title="Number of threads")
plt.savefig("density_comparison.jpg")
plt.show()

